<html>
<body>





SEARCH<?php

		require __DIR__. '../../../../vendor/autoload.php';


	$m =  new MongoDB\Client;
	$db = $m->test;
	$collection = $db->mycol;
	   $cursor =  $collection->find();
	   
	 foreach($cursor as $doc){
	   if(strpos($doc["Screen Name"], $_POST["user"]) != false)
		   echo '"'.$doc["Screen Name"].'","'.$doc["text"] ."<br>" . PHP_EOL;
		  
	   }   


//$_POST["user"]; 
?>

</body>
</html>