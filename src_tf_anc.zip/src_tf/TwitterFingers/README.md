Follow these instructions to successfully run the Twitter-Fingerz site via your local host.

1. Unzip the src_tf folder.
2. Copy the src_tf (unzipped) folder to your XAMPP htdocs folder. 
	Ex. C:\xampp\htdocs
3. Double-click the src_tf folder in your htdocs folder.
4. Double-click the 'TwitterFingers'.
5. Ensure the 'TwitterFingerz.php' file is inside the folder along with: 'StreamManipulation.php', 'StreamAccess.php', 'table_design.css', and a 'tmhOAuth' folder.
3. Open the XAMPP control panel and ensure the Apache server is running. 
4. In your web browser's address bar, enter "localhost/" plus 
	the path to your 'TwitterFingerz.php' file: 'localhost/src_tf/TwitterFingers/TwitterFingerz.php'.
5. The website should open to a heading with all of the team members names, and begin the stream of tweets

The page will constantly update with tweets. Tweets are displayed in string JSON format. The information will look very unorganized. The next iteration will focus on organizing and parsing this data for display.

This stream is streaming all of the tweets that are from the Twitter Account @espn and @washingtonpost.

Right now the stream returns 

	Tweets created by the user  @MarchMadness.
	Tweets which are retweeted by the user @MarchMadness.
	Replies to any Tweet created by the user @MarchMadness.
	Retweets of any Tweet created by the user @MarchMadness.
	Manual replies, created without pressing a reply button (e.g. “@twitterapi I agree”).

We realize that this project only needs to get original tweets from users, and not mentions and retweets by other people. Our stream will only display orignial tweets in future iterations. We included this example of the stream to show that we have made progress in being able to connect to the Twitter Streaming API and gather data.



	