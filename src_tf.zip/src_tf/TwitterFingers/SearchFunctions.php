<html>


<body>


<form action="SearchBackEnd.php" method="post">
Search User: <input type="text" name="user"><br>
<input type="submit">
</form>



</body>

<?php


?>



</html>


