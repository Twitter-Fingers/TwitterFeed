
<html>
<head>
<script type="text/javascript" src="table.js"></script>
<link rel="stylesheet" href="table_design.css">
<h1><font color = “#4099FF”><center>Twitter-Fingerz</center></font></h1>
<h2><center>by Anisha Carter, Taylor Clark, Dominique Collins, Julian Mathis, Sydney Parker, and Dorian Woods<center></h2>
<!--||-->
</head>
<body>


<!-- Scrollable box the stream of tweets will be displayed in -->
<div style="height:220px;width:1220px;border:1px solid #ccc;font:16px/26px Georgia, Garamond, Serif;overflow:auto;">
As you can see, once there's enough text in this box, the box will grow scroll bars... that's why we call it a scroll box! You could also place an image into the scroll box.

<br>

TWEETS ARE (WILL BE) BELOW 

<br>
<br>

	<?php require "tmhOAuth/StreamManipulationTest.php"; ?>

<br>	

</div>



<!-- Test for php require (Julian)


 <?php 
 //require "tmhOAuth/StreamManipulationTest.php"; ?> 
 -->


	<table><center>
	<thead>
		<TD><font color = black><center>USER</center></font></TD><TD><font color = black><center>TWEETS</center></font></TD>
	</thead>
		
	</center></table>
	<a class="twitter-timeline" data-height="500" href="https://twitter.com/MarketWatch/lists/finance-twitter">A Twitter List by MarketWatch</a> 
	<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
	<?php
	   // connect to mongodb
	   $m = new MongoClient();
		
	   echo "Connection to database successfully";
	   // select a database
	   //$db = $m->mydb;
		
	   //echo "Database mydb selected";
	?>
</body>

</html>
